'''

Assumptions for class Dish :
    1) Each Dish will be having a valid name
'''


class Dish:

    def __init__(self,name):
        self.name = name
